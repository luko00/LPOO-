package Grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Vectores extends JFrame {



	ecuacion2x2 ventana_ecuaciones_2x2 = new ecuacion2x2();
	ecuacion3x3 ventana_ecuaciones_3x3 = new ecuacion3x3();
	Matrices ventana_Matrices = new Matrices();
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vectores frame = new Vectores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private static void presentarVectorR2() {
		VectoresR2 misVectoresR2 = new VectoresR2();
		misVectoresR2.setVisible(true);
	}

	private static void presentarVectorR3() {
		VectoresR3 misVectoresR3 = new VectoresR3();
		misVectoresR3.setVisible(true);
	}
	/**
	 * Create the frame.
	 */
	public Vectores() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 302);
		contentPane = new JPanel();
		contentPane.setForeground(Color.RED);
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" Vectores");
		lblNewLabel.setForeground(Color.GREEN);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(148, 0, 136, 56);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Eliga que tipo de vector");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setToolTipText("");
		lblNewLabel_1.setBounds(105, 56, 235, 48);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("R2");
		btnNewButton.setForeground(Color.GREEN);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentarVectorR2();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(57, 130, 151, 56);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("R3");
		btnNewButton_1.setForeground(Color.GREEN);
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentarVectorR3();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBounds(240, 130, 144, 56);
		contentPane.add(btnNewButton_1);
		
		JButton atras = new JButton("HOME");
		atras.setForeground(Color.RED);
		atras.setBackground(Color.LIGHT_GRAY);
		atras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ventana_Menu1.setVisible(true);
				setVisible(false);
			}
		});
		atras.setBounds(46, 217, 101, 35);
		contentPane.add(atras);
		
		JButton btnEcuaciones = new JButton("2x2");
		btnEcuaciones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_ecuaciones_2x2.setVisible(true);
				dispose();
			}
		});
		btnEcuaciones.setForeground(Color.MAGENTA);
		btnEcuaciones.setBackground(Color.LIGHT_GRAY);
		btnEcuaciones.setBounds(289, 217, 57, 35);
		contentPane.add(btnEcuaciones);
		
		JButton atras_1_1 = new JButton("Matrices");
		atras_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ventana_Matrices1.setVisible(true);
				ventana_Matrices.setVisible(true);	
				dispose();
			}
		});
		atras_1_1.setForeground(Color.RED);
		atras_1_1.setBackground(Color.LIGHT_GRAY);
		atras_1_1.setBounds(172, 217, 101, 35);
		contentPane.add(atras_1_1);
		
		JButton btnx = new JButton("3x3");
		btnx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventana_ecuaciones_3x3.setVisible(true);
				dispose();
			}
		});
		btnx.setForeground(Color.MAGENTA);
		btnx.setBackground(Color.LIGHT_GRAY);
		btnx.setBounds(343, 217, 57, 35);
		contentPane.add(btnx);
	}
}
