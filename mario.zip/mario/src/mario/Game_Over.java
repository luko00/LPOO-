package mario;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;



public class Game_Over {
    public static void main(String[] args) {
        JFrame ventana = new JFrame("Game Over");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(1300, 630);
        ventana.setResizable(false);

        InicioGameOver inicioGameOver = new InicioGameOver();
        ventana.add(inicioGameOver);
        ventana.setVisible(true);
    }

    private static class InicioGameOver extends JPanel implements KeyListener {
        private BufferedImage backgroundImage;
        private Font pixelFont;

        public InicioGameOver() {
            addKeyListener(this);
            setFocusable(true);
            setBackground(Color.BLACK);

            // Cargar la imagen de fondo
            try {
                backgroundImage = ImageIO.read(new File("E:\\mario\\src\\mario\\gameover.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Fuente predeterminada
            pixelFont = new Font("Arial", Font.PLAIN, 40); // Fuente de respaldo
        

        try {
            InputStream is = getClass().getResourceAsStream("Fuente_retro.ttf");
            pixelFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(25f); // Tamaño de 25
        } catch (Exception e) {
            e.printStackTrace();
            pixelFont = new Font("Arial", Font.PLAIN, 40); // Fuente de respaldo
        }
    }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Dibujar la imagen de fondo
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }

            g.setFont(pixelFont); // Aplicar la fuente
            FontMetrics metrics = g.getFontMetrics(pixelFont);

            // Dibujar el texto centrado
            String texto = "Pulse [R] para volver al menú";
            int textoX = (getWidth() - metrics.stringWidth(texto)) / 2;

            g.setColor(Color.BLACK);
            g.drawString(texto, textoX, 500); // Ajustar la posición vertical
        }

        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_R) {
                volverAlMenu();
            }
        }

        private void volverAlMenu() {
            JFrame ventana = (JFrame) this.getTopLevelAncestor();
            ventana.remove(this);
            JuegoAventuras menuPrincipal = new JuegoAventuras(); // Volver al menú principal
            ventana.add(menuPrincipal);
            ventana.revalidate();
            ventana.repaint();
            
            // Asegúrate de que el menú tenga el foco para recibir eventos de teclado
            menuPrincipal.requestFocusInWindow();
        }

        @Override
        public void keyReleased(KeyEvent e) {}

        @Override
        public void keyTyped(KeyEvent e) {}
    }
}
